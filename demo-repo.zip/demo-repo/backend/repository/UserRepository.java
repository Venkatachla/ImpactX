package com.example.demo.repository;

import com.example.demo.dto.UserDTO;
import org.springframework.stereotype.Repository;

@Repository
public class UserRepository {
    // Database access simulation
}
