package com.example.demo.service;

import com.example.demo.dto.UserDTO;
import org.springframework.stereotype.Service;

@Service
public class UserService {
    public UserDTO getUser(Long id) {
        return new UserDTO(id.toString(), "John Doe", "john.doe@example.com");
    }

    public void calculateDiscount() {
        // Deprecated pricing logic
    }
}
