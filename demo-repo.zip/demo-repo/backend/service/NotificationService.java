package com.example.demo.service;

import com.example.demo.dto.UserDTO;
import org.springframework.stereotype.Service;

@Service
public class NotificationService {
    private final UserService userService;

    public NotificationService(UserService userService) {
        this.userService = userService;
    }

    public void notifyUser(Long userId) {
        UserDTO user = userService.getUser(userId);
        System.out.println("Notify: " + user.getEmail());
    }
}
