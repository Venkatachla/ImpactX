package com.example.demo.service;

import org.springframework.stereotype.Service;

@Service
public class AuthService {
    private final UserService userService;

    public AuthService(UserService userService) {
        this.userService = userService;
    }

    public boolean authenticate(Long userId) {
        return userService.getUser(userId) != null;
    }
}
