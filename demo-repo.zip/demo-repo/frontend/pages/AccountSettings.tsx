import React, { useEffect, useState } from 'react';
import { userApi } from '../api/userApi';

export const AccountSettings = ({ userId }: { userId: string }) => {
  const [user, setUser] = useState<any>(null);

  useEffect(() => {
    userApi.getUser(userId).then(data => {
      setUser(data);
    });
  }, [userId]);

  const handleUpdate = () => {
    userApi.updateUser(userId, { email: 'new@example.com' });
  };

  if (!user) return <div>Loading...</div>;

  return (
    <div>
      <h1>Account Settings</h1>
      <button onClick={handleUpdate}>Update Email</button>
    </div>
  );
};
