import React, { useEffect, useState } from 'react';
import { userApi } from '../api/userApi';

export const ProfilePage = ({ userId }: { userId: string }) => {
  const [user, setUser] = useState<any>(null);

  useEffect(() => {
    userApi.getUser(userId).then(data => {
      setUser(data);
    });
  }, [userId]);

  if (!user) return <div>Loading...</div>;

  return (
    <div>
      <h1>Profile</h1>
      <p>Email: {user.email}</p>
    </div>
  );
};
