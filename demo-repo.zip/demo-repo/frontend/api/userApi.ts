import axios from 'axios';

export const userApi = {
  getUser: async (id: string) => {
    const response = await axios.get(`/api/users/${id}`);
    return response.data;
  },
  updateUser: async (id: string, data: any) => {
    const response = await axios.put(`/api/users/${id}`, data);
    return response.data;
  }
};
