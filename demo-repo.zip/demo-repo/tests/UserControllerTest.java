package com.example.demo.controller;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class UserControllerTest {
    @Test
    public void testGetUserById() {
        // unit test for UserController
        assertTrue(true);
    }
}
